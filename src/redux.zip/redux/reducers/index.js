
import loginReducer from "./auth.reducers/auth.reducer"
import signupReducer from "./auth.reducers/signup.reducer"
const AllReducers={
    loginReducer,
    signupReducer
}
export default AllReducers